class ex1
{
        public static void main(String args[])
        {
                System.out.println("Welcome");
        }
}
class ex2
{
        public static void main(String args[])
        {
                System.out.println("Good Bye");
        }
}
